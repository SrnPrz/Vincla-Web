import { SideMenu } from './Side-Menu';
import { BondsMenu } from './Bonds-Menu';
import { Routes, Route } from 'react-router-dom';
import { RemindersMenu } from './Reminders-Menu';
import { OverallConditionMenu } from './Overall-Condition-Menu';
import { SettingsMenu } from './Settings-Menu';

export const MainContent = ({menuVisible}) => {

    return (
        <main id="mainContent">
            <div className={"sideMenuWrap" + (!menuVisible ? " hideOnSmallScreen" : "")}>
                <SideMenu></SideMenu>
            </div>
            <div id="pageContent">
                <Routes>
                    <Route path="/vinculos/*" element={ <BondsMenu></BondsMenu> }></Route>
                    <Route path="/recordatorios" element={ <RemindersMenu></RemindersMenu> }></Route>
                    <Route path="/estado-general" element={ <OverallConditionMenu></OverallConditionMenu> }></Route>
                    <Route path="/configuracion" element={ <SettingsMenu></SettingsMenu> }></Route>
                </Routes>
            </div>
        </main>
    )
}