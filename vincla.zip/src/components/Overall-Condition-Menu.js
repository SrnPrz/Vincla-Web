export const OverallConditionMenu = () => {
    const monthSummary = [
        {
            "icon" : "/img/red_hourglass.svg",
            "content" : "No interactuaste con 2 vínculos íntimos",
            "canBeMarked" : false
        },
        {
            "icon" : "/img/red_heart.svg",
            "content" : "Tuviste 4 gestos afectivos",
            "canBeMarked" : false
        },
        {
            "icon" : "/img/red_vitals.svg",
            "content" : "Hubo 1 conflicto y 1 reconciliación",
            "canBeMarked" : false
        },
        {
            "icon" : "/img/red_trophy.svg",
            "content" : "Plan sin pantallas con alguien cercano",
            "canBeMarked" : true
        },
        {
            "icon" : "/img/red_trophy.svg",
            "content" : "Da las gracias sin motivo a alguien que siempre está",
            "canBeMarked" : true
        }
    ];

    const inactiveBonds = [
        {
            "icon" : "/img/red_hourglass.svg",
            "content" : "Llevas mucho sin interactuar con Joel Trabajo. ¿Quieres borrar este vínculo de vincla?",
        }
    ];

    const networkCare = [
        {
            "icon" : "/img/trophy.svg",
            "content" : "<strong>Reto mensual:</strong> \"Da las gracias sin motivo a alguien que siempre está\""
        },
        {
            "icon" : "/img/trophy.svg",
            "content" : "<strong>Reto mensual:</strong> \"Plan sin pantallas con alguien cercano\""
        },
        {
            "icon" : "/img/red_target.svg",
            "content" : "<strong>Reto mensual:</strong> \"Proponer un plan sin hablar del conflicto\""
        }
    ]

    return (
        <div className="overallConditionMenu">
            <h1>Estado general</h1>
            <h2>Resumen mensual</h2>
            <div className="monthSummarySection infoSection">
                {
                    monthSummary.map((entry, index) => (
                        <article className="monthSummaryEntry" key={index}>
                            <div>
                                <img src={ entry.icon } className="monthSummaryIcon" width="36px" height="36px"></img>
                                <span className="monthSummaryContent">{ entry.content }</span>
                            </div>
                            { entry.canBeMarked ? <button type="button" className="monthSummaryBtn">Marcar como hecho</button> : "" }
                                
                        </article>
                    ))
                }
            </div>
            <h2>Vínculos inactivos</h2>
            <div className="inactiveBondsSection infoSection">
                {
                    inactiveBonds.map((entry, index) => (
                        <article className="entryBar" key={index}>
                            <div className="entryBarLeft">
                                <img src={ entry.icon } className="entryBarIcon" width="24px" height="24px"></img>
                                <span className="entryBarContent">{ entry.content }</span>
                            </div>
                            <div className="entryBarRight">
                                <button type="button" className="entryBarIconBtn"><img src="/img/check.svg" width="24px" height="24px" alt="Check"></img></button>
                                <button type="button" className="entryBarIconBtn"><img src="/img/close.svg" width="24px" height="24px" alt="Close"></img></button>
                            </div>
                        </article>
                    ))
                }
            </div>

            <h2>Cuida tu red</h2>

            <div className="networkCareSection infoSection">
                {
                    networkCare.map((entry, index) => (
                        <article className="entryBar" key={index}>
                            <div className="entryBarRight">
                                <img src={ entry.icon } className="entryBarIcon" width="24px" height="24px"></img>
                                <span className="entryBarContent" dangerouslySetInnerHTML={{ __html: entry.content }}></span>
                            </div>
                            <div className="entryBarLeft">
                                <button type="button" className="entryBarBtn">Activar</button>
                                <button type="button" className="entryBarBtn">Descartar</button>
                            </div>
                        </article>
                    ))
                }
            </div>
        </div>
    )
}