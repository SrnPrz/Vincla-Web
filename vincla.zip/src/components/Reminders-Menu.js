import { useState } from 'react';

export const RemindersMenu = () => {
    const todayReminders = [
        {
            "icon" : "/img/present.svg",
            "content" : "Hoy es el cumpleaños de Sofía Martínez"
        }
    ];


    const lastContactReminders = [
        {
            "icon" : "/img/clock2.svg",
            "content" : "Hace 3 semanas que no quedas con Carla Ruiz"
        },
        {
            "icon" : "/img/clock2.svg",
            "content" : "Han pasado 45 días desde tu llamada con Lucas García"
        }
    ];

    const conflictReminders = [
        {
            "icon" : "/img/thumb-down.svg",
            "content" : "Tu conflicto con Emma Ruiz está pendiente de resolver"
        },
        {
            "icon" : "/img/thumb-down.svg",
            "content" : "Tu conflicto con Juan García está pendiente de resolver"
        }
    ];

    const pendingReminders = [
        {
            "icon" : "/img/thunder.svg",
            "content" : "Tienes pendiente de quedar con Pablo el Lunes que viene"
        }
    ];

    const displayReminders = (reminders) => {
        return reminders.map((entry, index) => (
            <article className="infoEntry" key={index}>
                <img src={ entry.icon } className="reminderEntryIcon" width="24px" height="24px"></img>
                <span className="reminderContent">{ entry.content }</span>
            </article>
        ))
    }

    return (
        <div className="reminderMenu">
            <h1>Recordatorios</h1>
            <h2>Hoy</h2>
            <div className="infoSection">
                { displayReminders(todayReminders) }
            </div>
            <h2>Último contacto</h2>
            <div className="infoSection">
                { displayReminders(lastContactReminders) }
            </div>
            <h2>En conflicto</h2>
            <div className="infoSection">
                { displayReminders(conflictReminders) }
            </div>
            <h2>Pendiente</h2>
            <div className="infoSection">
                { displayReminders(pendingReminders) }
            </div>
        </div>
    )
}