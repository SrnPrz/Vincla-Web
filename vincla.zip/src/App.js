import './App.css';
import { Header } from './components/Header';
import { BrowserRouter, Route, Router, Routes } from 'react-router-dom';
import { MainContent } from './components/Main-Content';
import { useState } from 'react';

function App() {
  const [menuVisible, setMenuVisible] = useState(false);

  return (
    <div className="App">
      <Header setMenuVisible={ () => setMenuVisible(prev => !prev) }></Header>
      <BrowserRouter>
        <Routes>
          <Route path="/*" element={ <MainContent menuVisible={menuVisible}></MainContent> }></Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
